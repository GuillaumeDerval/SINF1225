2ième rapport Groupe 08, pour le cours Conception orientée objet et gestion de données.
19 avril 2013.

Ce dossier contient:
-Dans le dossier UserStories, les User Stories sous forme de document PDF.
-Dans le dossier CRC, les cartes CRC utilisées, sous forme de document PDF.
-Dans le dossier Schéma UML, le diagramme de classe conceptuel UML de notre application, sous forme de document PDF.
-Dans le dossier Séquence UML, 3 diagrammes de séquences UML correspondant à 3 user stories différentes, sous forme de documents PDF.

Les sources des documents, sous forme de fichier latex ou omnigraffle, sont également fournies.